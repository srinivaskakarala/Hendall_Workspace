package com.hendall.survey.services.ejb;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.apache.commons.collections4.CollectionUtils;

import com.hendall.survey.services.common.ServiceConstants;
import com.hendall.survey.services.datamodel.Answer;
import com.hendall.survey.services.datamodel.Options;
import com.hendall.survey.services.datamodel.Question;
import com.hendall.survey.services.datamodel.Section;
import com.hendall.survey.services.entities.StateProviderLu;
import com.hendall.survey.services.entities.StatesLu;

public class InfectionControlSpecialCases {

	public void processSpecialCases(List<Section> surverQuestionsList, EntityManager entityManager) {
		String selectedStateCode = null;
		for (Section section : surverQuestionsList) {
			for (Question question : section.getSurveyQuestionAnswerList()) {
				for (Answer answer : question.getAnswersList()) {
					if (answer.getHtmlControlId() == ServiceConstants.INFECTION_CONTROL_STATE_CONTROL_ID) {
						List<StatesLu> satesList = entityManager.createQuery("Select A from StatesLu A", StatesLu.class)
								.getResultList();
						answer.getHtmlOptions().clear();
						Options selectState = new Options();
						selectState.setKey("");
						selectState.setValue("Select a state");
						answer.getHtmlOptions().add(selectState);

						for (StatesLu statesLu : satesList) {
							Options option = new Options();
							option.setKey(statesLu.getStateCode());
							option.setValue(statesLu.getStateName());
							answer.getHtmlOptions().add(option);
						}
						selectedStateCode = answer.getAnswer();
					}
					if (answer.getHtmlControlId() == ServiceConstants.INFECTION_CONTROL_HOSPITAL_NAME_CONTROL_ID) {
						answer.getHtmlOptions().clear();
						Options selectProvider = new Options();
						selectProvider.setKey("");
						selectProvider.setValue("Select a hospital");
						answer.getHtmlOptions().add(selectProvider);

						List<StateProviderLu> stateProvidersList = entityManager.createQuery(
								"Select A from  StateProviderLu  A join fetch A.providersLu join fetch A.statesLu",
								StateProviderLu.class).getResultList();
						Map<String, List<Options>> dependentHtmlOptionsMap = new HashMap<String, List<Options>>();
						for (StateProviderLu stateProviderLu : stateProvidersList) {
							Options option = new Options();
							option.setKey(stateProviderLu.getProvidersLu().getProviderKey().toString());
							option.setValue(stateProviderLu.getProvidersLu().getProviderName());
							if (dependentHtmlOptionsMap.containsKey(stateProviderLu.getStatesLu().getStateCode())) {
								dependentHtmlOptionsMap.get(stateProviderLu.getStatesLu().getStateCode()).add(option);
							} else {
								List<Options> arrayList = new ArrayList<Options>();
								arrayList.add(option);
								dependentHtmlOptionsMap.put(stateProviderLu.getStatesLu().getStateCode(), arrayList);
							}

						}
						answer.setDependentHtmlOptionsMap(dependentHtmlOptionsMap);
						if (selectedStateCode != null) {
							answer.setHtmlOptions(dependentHtmlOptionsMap.get(selectedStateCode));
						}
					}

				}
			}
		}

	}

	public void addAddtionalQuestions(List<Section> surverQuestionsList) {
		if (CollectionUtils.isEmpty(surverQuestionsList)) {
			return;
		}
		Section section = new Section();
		section.setSectionTitle(ServiceConstants.INFECTION_CONTROL_ADDTIONAL_COMMENTS_SECTION_TITLE);
		section.setSurveyKey(surverQuestionsList.get(0).getSurveyKey());
		section.setUserKey(surverQuestionsList.get(0).getUserKey());
		Question question = new Question();
		question.setQuestionId(ServiceConstants.INFECTION_CONTROL_ADDTIONAL_COMMENTS_ID);
		question.setQuestionText(ServiceConstants.INFECTION_CONTROL_ADDTIONAL_COMMENTS_QUESTION);
		Answer answer = new Answer();
		answer.setHtmlControlId(ServiceConstants.INFECTION_CONTROL_ADDTIONAL_COMMENTS_ID);
		answer.setHtmlControlType(ServiceConstants.HTML_CONTROL_TEXT_AREA);
		answer.setDefaultVisible(true);
		question.getAnswersList().add(answer);
		section.getSurveyQuestionAnswerList().add(question);
		surverQuestionsList.add(section);

		/*
		 * Section emailSection = new Section();
		 * emailSection.setSectionTitle(ServiceConstants.
		 * INFECTION_CONTROL_ADDTIONAL_APPROVER_DETAILS_SECTION_TITLE);
		 * emailSection.setSurveyKey(surverQuestionsList.get(0).getSurveyKey());
		 * emailSection.setUserKey(surverQuestionsList.get(0).getUserKey());
		 * Question emailQuestion = new Question();
		 * emailQuestion.setQuestionId(ServiceConstants.
		 * INFECTION_CONTROL_APPROVER_ID);
		 * emailQuestion.setQuestionText(ServiceConstants.
		 * INFECTION_CONTROL_ADDTIONAL_APPROVER_DETAILS_QUESTION); Answer
		 * emailAnswer = new Answer();
		 * emailAnswer.setHtmlControlId(ServiceConstants.
		 * INFECTION_CONTROL_APPROVER_ID);
		 * emailAnswer.setHtmlControlType(ServiceConstants.HTML_CONTROL_TEXT_BOX
		 * ); emailAnswer.setDefaultVisible(true);
		 * emailQuestion.getAnswersList().add(emailAnswer);
		 * emailSection.getSurveyQuestionAnswerList().add(emailQuestion);
		 * surverQuestionsList.add(emailSection);
		 */

	}
}
