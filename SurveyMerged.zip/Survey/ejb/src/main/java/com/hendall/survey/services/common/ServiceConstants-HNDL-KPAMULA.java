package com.hendall.survey.services.common;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class ServiceConstants {
	private ServiceConstants() {
	}

	public static String INFECTION_CONTROL_FILE_NAME = "Hospital_Infection_Control_Worksheet_v0_9a.json";
	public static String HELP_PDF_FOLDER = "helppdf";
	public static String PROPERTIES_FOLDER = "survey.folderpath";
	public static String PROPERTIES_FILE = "survey.jsonfile";

	public static final String UNABLE_TO_OBSERVE = "Unable to observe";
	public static final String NA = "N/A";

	public static String STATUS_REJECT = "Rejected";
	public static String STATUS_APPROVE = "Approved";
	public static String STATUS_IN_PROGRESS = "In Progress";
	public static String STATUS_IN_PENDING_REVIEW = "Pending Review";
	public static String STATUS_IN_SUBMITTED = "Submitted";

	public static String EMAIL_FROM_ADDRESS = "kalyan.pamula@hendall.com";

	public static String EMAIL_SUBJECT = "New Survey Review pending";
	public static String EMAIL_MESSAGE = "New survey has been assigned to you. Please login to your account.";

	public static Integer INFECTION_CONTROL_STATE_CONTROL_ID = 100;
	public static Integer INFECTION_CONTROL_HOSPITAL_NAME_CONTROL_ID = 200;
	public static Integer INFECTION_CONTROL_HOSPITAL_CCN_ID = 300;
	public static final Integer INFECTION_CONTROL_ADDTIONAL_COMMENTS_ID = -1;
	public static final String INFECTION_CONTROL_ADDTIONAL_COMMENTS_QUESTION = "You can use this section to include any additional comments or observations you may have, regarding this survey.";
	public static final String INFECTION_CONTROL_ADDTIONAL_COMMENTS_SECTION_TITLE = "Survey Notes";

	public static final Integer INFECTION_CONTROL_APPROVER_ID = -2;
	public static final String INFECTION_CONTROL_ADDTIONAL_APPROVER_DETAILS_SECTION_TITLE = "Survey Approver Details";
	public static final String INFECTION_CONTROL_ADDTIONAL_APPROVER_DETAILS_QUESTION = "Please enter the email address of your supervisor in this section. \n Upon submission of the survey, an email will be sent to your supervisor, for their appproval.";
	public static final String INFECTION_CONTROL_ADDTIONAL_APPROVER_EMAIL = "Supervisor Email Address:";

	public static final String DATA_SAPERATOR = "\\|\\|";

	public static final String HTML_CONTROL_RADIO = "radio";
	public static final String HTML_CONTROL_CHECK_BOX = "checkbox";
	public static final String HTML_CONTROL_SELECT = "select";
	public static final String HTML_CONTROL_TEXT_BOX = "textbox";
	public static final String HTML_CONTROL_DATE = "date";
	public static final String HTML_CONTROL_NUMBER = "number";
	public static final String HTML_CONTROL_TEXT_AREA = "textarea";
	public static final List<String> inputTextComponents = new ArrayList<String>();
	public static final List<String> singleValueCompoents = new ArrayList<String>();
	public static final List<String> multipleSelectionComponents = new ArrayList<String>();

	public static final String REQUEIRED_MESSAGE = "Required.";
	
	public static final String INFECTION_CONTROL_NO_OBSERVATION_AVALIABLE_123710="No observations available (If selected, ALL questions from 4.A.3 – 4.A.6 will be blocked)";
	public static final String INFECTION_CONTROL_SECON_OBSERVATION_NOT_AVALIABLE_123710="Second observation not available (If selected, questions 4.A.3 – 4.A.6 RIGHT column will be blocked)";
	public static List<String> LIST_4A3_TO_4A6 = new ArrayList<String>();
	public static Integer INFECTION_CONTROL_SKIP_4A3_TO_4A6_ID=123710;
	
	public static final String INFECTION_CONTROL_NO_OBSERVATION_AVALIABLE_134710="No observations available (If selected, ALL questions from 4.B.2 – 4.B.7 will be blocked)";
	public static final String INFECTION_CONTROL_SECON_OBSERVATION_NOT_AVALIABLE_134710="Second observation not available (If selected, questions 4.B.2 – 4.B.7 RIGHT column will be blocked)";
	public static List<String> LIST_4B2_TO_4B7 = new ArrayList<String>();
	public static Integer INFECTION_CONTROL_SKIP_4B2_TO_4B7_ID=134710;
	
	public static final String INFECTION_CONTROL_NO_OBSERVATION_AVALIABLE_88600="Yes";
	public static final String INFECTION_CONTROL_SECON_OBSERVATION_NOT_AVALIABLE_88600="No";
	public static List<String> LIST_3A6_TO_3A18 = new ArrayList<String>();
	public static Integer INFECTION_CONTROL_SKIP_3A6_TO_3A18_ID=88600;
	
	public static List<String> INFECTION_CONTROL_NO_OBSERVATION_AVALIABLE_RENDER_TRUE_LIST = new ArrayList<String>();
	public static List<String> INFECTION_CONTROL_SECOND_OBSERVATION_AVALIABLE_RENDER_FALSE_LIST = new ArrayList<String>();
	public static Map<Integer, List<String>> infectionControlDepenentComponents = new HashMap<Integer, List<String>>();
	public static List<Integer> INFECTION_CONTROL_NO_SECOND_OBSERVATION_ID_LIST = new ArrayList<Integer>();

	static {
		inputTextComponents.add(HTML_CONTROL_TEXT_BOX);
		inputTextComponents.add(HTML_CONTROL_DATE);
		inputTextComponents.add(HTML_CONTROL_NUMBER);
		inputTextComponents.add(HTML_CONTROL_TEXT_AREA);

		singleValueCompoents.add(HTML_CONTROL_TEXT_BOX);
		singleValueCompoents.add(HTML_CONTROL_DATE);
		singleValueCompoents.add(HTML_CONTROL_NUMBER);
		singleValueCompoents.add(HTML_CONTROL_TEXT_AREA);
		singleValueCompoents.add(HTML_CONTROL_RADIO);
		singleValueCompoents.add(HTML_CONTROL_SELECT);

		multipleSelectionComponents.add(HTML_CONTROL_RADIO);
		multipleSelectionComponents.add(HTML_CONTROL_CHECK_BOX);
		multipleSelectionComponents.add(HTML_CONTROL_SELECT);

		INFECTION_CONTROL_NO_OBSERVATION_AVALIABLE_RENDER_TRUE_LIST.add(INFECTION_CONTROL_NO_OBSERVATION_AVALIABLE_123710);
		INFECTION_CONTROL_NO_OBSERVATION_AVALIABLE_RENDER_TRUE_LIST.add(INFECTION_CONTROL_NO_OBSERVATION_AVALIABLE_134710);
		INFECTION_CONTROL_NO_OBSERVATION_AVALIABLE_RENDER_TRUE_LIST.add(INFECTION_CONTROL_NO_OBSERVATION_AVALIABLE_88600);

		INFECTION_CONTROL_SECOND_OBSERVATION_AVALIABLE_RENDER_FALSE_LIST.add(INFECTION_CONTROL_SECON_OBSERVATION_NOT_AVALIABLE_123710);
		INFECTION_CONTROL_SECOND_OBSERVATION_AVALIABLE_RENDER_FALSE_LIST.add(INFECTION_CONTROL_SECON_OBSERVATION_NOT_AVALIABLE_123710);
		INFECTION_CONTROL_SECOND_OBSERVATION_AVALIABLE_RENDER_FALSE_LIST.add(INFECTION_CONTROL_SECON_OBSERVATION_NOT_AVALIABLE_88600);
		
		INFECTION_CONTROL_NO_SECOND_OBSERVATION_ID_LIST.add(INFECTION_CONTROL_SKIP_4A3_TO_4A6_ID);
		INFECTION_CONTROL_NO_SECOND_OBSERVATION_ID_LIST.add(INFECTION_CONTROL_SKIP_4B2_TO_4B7_ID);
		INFECTION_CONTROL_NO_SECOND_OBSERVATION_ID_LIST.add(INFECTION_CONTROL_SKIP_3A6_TO_3A18_ID);
		
		LIST_4A3_TO_4A6.add("4.A.3 Hand hygiene is performed before and after insertion of the urinary catheter.");
		LIST_4A3_TO_4A6.add("4.A.4 Catheter is placed using aseptic technique and sterile equipment.");
		LIST_4A3_TO_4A6.add("4.A.5 Catheter is secured properly after insertion.<br><br>Note: This may not apply to catheters placed in the OR if the catheter is removed in the OR immediately after the procedure.");
		LIST_4A3_TO_4A6.add("4.A.6 Catheter insertion and indication are documented.");
		infectionControlDepenentComponents.put(INFECTION_CONTROL_SKIP_4A3_TO_4A6_ID, LIST_4A3_TO_4A6);
		
		
		LIST_4B2_TO_4B7.add("4.B.2 Hand Hygiene is performed before and after insertion.");
		LIST_4B2_TO_4B7.add("4.B.3 Maximal barrier precautions are used for insertion (includes use of cap, mask, sterile gown, sterile gloves, and a sterile full body drape).");
		LIST_4B2_TO_4B7.add("4.B.4 > 0.5% chlorhexidine with alcohol is used for skin antisepsis prior to insertion (If contraindicated [e.g., neonatal population], tincture of iodine, an iodophor, or 70% alcohol can be used as alternatives).");
		LIST_4B2_TO_4B7.add("4.B.5 Sterile gauze or sterile, transparent, semi-permeable dressing is used to cover catheter site (may not apply for well-healed tunneled catheters).");
		LIST_4B2_TO_4B7.add("4.B.6 If the femoral site is used for central venous catheter insertion for adults, justification for this site is in the medical record.");
		LIST_4B2_TO_4B7.add("4.B.7 Central venous line insertion and indication are documented.");
		infectionControlDepenentComponents.put(INFECTION_CONTROL_SKIP_4B2_TO_4B7_ID, LIST_4B2_TO_4B7);
		
		
		LIST_3A6_TO_3A18.add("3.A.6 Flexible endoscopes are inspected for damage and leak tested as part of each reprocessing cycle.<br><br>(An endoscope is an instrument designed to visually examine the interior of a bodily canal or hollow organ such as the colon. bladder, or stomach)");
		LIST_3A6_TO_3A18.add("3.A.7 Items are thoroughly pre-cleaned according to manufacturer instructions and visually inspected for residual soil prior to high-level disinfection.<br><br>Note: For instruments with lumens (e.g., endoscopes), pre-cleaning of devices must include all channels using cleaning brushes of appropriate size.");
		LIST_3A6_TO_3A18.add("3.A.8 Enzymatic cleaner or detergent is used and discarded according to manufacturer's instructions (typically after each use).");
		LIST_3A6_TO_3A18.add("3.A.9 Cleaning brushes are single-use, disposable items or, if reusable, cleaned and either high-level disinfected or sterilized (per manufacturer's instructions) at least daily.");
		LIST_3A6_TO_3A18.add("3.A.10 For chemicals used in high-level disinfection, manufacturer's instructions are followed for:<br><ul><li>Preparation,</li><li>Testing for appropriate concentration, and</li><li>Replacement (e.g., prior to expiration or loss of efficacy)</li></ul>");
		LIST_3A6_TO_3A18.add("3.A.11 If automated reprocessing equipment is used, the manufacturer's recommended connectors are used to assure that all endoscope channels are appropriately disinfected.");
		LIST_3A6_TO_3A18.add("3.A.12 Devices undergo disinfection for the appropriate length of time as specified by manufacturer's instructions.");
		LIST_3A6_TO_3A18.add("3.A.13 Devices undergo disinfection at the appropriate temperature as specified by manufacturer's instructions.");
		LIST_3A6_TO_3A18.add("3.A.14 After high-level disinfection, devices are rinsed with sterile water, filtered water, or tap water followed by a rinse with 70%-90% ethyl or isopropyl alcohol.<br><br>Note: There is no recommendation to use sterile or filtered water rather than tap water for rinsing semi-critical equipment that contact the mucous membranes of the rectum or vagina.");
		LIST_3A6_TO_3A18.add("3.A.15 Devices are dried thoroughly prior to reuse.<br><br>Note: For instruments with lumens (e.g., endoscopes), this includes flushing all channels with alcohol and forcing air through the channels.");
		LIST_3A6_TO_3A18.add("3.A.16 Routine maintenance procedures for high-level disinfection equipment are performed regularly. (Confirm maintenance records are available.)");
		LIST_3A6_TO_3A18.add("3.A.17 After high-level disinfection, devices are stored in a manner to protect from damage or contamination<br><br>Note: Endoscopes must be hung in a vertical position.");
		LIST_3A6_TO_3A18.add("3.A.18 The hospital has a system in place to identify which endoscope was used on a patient for each procedure.");
		infectionControlDepenentComponents.put(INFECTION_CONTROL_SKIP_3A6_TO_3A18_ID,LIST_3A6_TO_3A18);		

	}

}
