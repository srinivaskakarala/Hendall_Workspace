package com.hendall.survey.services.datamodel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;

import com.hendall.survey.services.common.ServiceConstants;
import com.hendall.survey.util.Comparators;

public class Question implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4011894524068974035L;
	private Integer questionId;
	private String questionText;
	private boolean renderAddObservation;
	private boolean renderQuestion = true;
	private boolean disableAddObservation = false;
	private String citableTagName;
	private String citableTagURL;
	private Validation validation;
	private List<Answer> answersList;

	public void populateObservationNumbers() {

		if (CollectionUtils.isNotEmpty(answersList)&&renderAddObservation) {
			ArrayList<Answer> tmp = new ArrayList<Answer>();
			ArrayList<Answer> tmpNoRemoveObsevation = new ArrayList<Answer>();
			tmp.add(answersList.get(0));
			tmp.add(answersList.get(1));
			int counter = 2;
			for (Answer answer : answersList) {
				if (answer.isRenderRemoveButton()&&(answer.getHtmlControlType().equals(ServiceConstants.HTML_CONTROL_RADIO))) {
					answer.setObservationNumber(counter);
					counter++;
					
				}
			}
			for (Answer answer : answersList) {
				if (answer.isRenderRemoveButton()){
					tmp.add(answer);
				}
				else{
					tmpNoRemoveObsevation.add(answer);
				}
			}

			answersList.clear();
			answersList.addAll(tmp);
			answersList.addAll(tmpNoRemoveObsevation);
			
			
		}

	}

	public int getObsevationNumber() {
		int numberOfObservations = 0;
		if (CollectionUtils.isNotEmpty(answersList)) {
			for (Answer answer : answersList) {
				if (answer.isDefaultVisible()
						&& answer.getHtmlControlType().equals(ServiceConstants.HTML_CONTROL_TEXT_AREA)) {
					numberOfObservations++;
				}
			}
			return numberOfObservations + 1;
		}
		return 2;

	}

	public String getCitableTagName() {
		return citableTagName;
	}

	public void setCitableTagName(String citableTagName) {
		this.citableTagName = citableTagName;
	}

	public String getCitableTagURL() {
		return citableTagURL;
	}

	public void setCitableTagURL(String citableTagURL) {
		this.citableTagURL = citableTagURL;
	}

	public Integer getQuestionId() {
		return questionId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}

	public String getQuestionText() {
		return questionText;
	}

	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}

	public List<Answer> getAnswersList() {
		if (answersList == null) {
			answersList = new ArrayList<Answer>();
		}
		return answersList;
	}

	public void setAnswersList(List<Answer> answersList) {
		this.answersList = answersList;
	}

	public boolean isRenderAddObservation() {
		return renderAddObservation;
	}

	public void setRenderAddObservation(boolean renderAddObservation) {
		this.renderAddObservation = renderAddObservation;
	}

	public boolean isDisableAddObservation() {
		return disableAddObservation;
	}

	public void setDisableAddObservation(boolean disableAddObservation) {
		this.disableAddObservation = disableAddObservation;
	}

	public boolean isRenderQuestion() {
		return renderQuestion;
	}

	public void setRenderQuestion(boolean renderQuestion) {
		this.renderQuestion = renderQuestion;
	}

	public Validation getValidation() {
		return validation;
	}

	public void setValidation(Validation validation) {
		this.validation = validation;
	}

}
