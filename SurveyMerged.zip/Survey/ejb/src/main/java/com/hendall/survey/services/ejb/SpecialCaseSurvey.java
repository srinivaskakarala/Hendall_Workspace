package com.hendall.survey.services.ejb;

public abstract class SpecialCaseSurvey {
	
	public abstract void processSpecialCases();

}
