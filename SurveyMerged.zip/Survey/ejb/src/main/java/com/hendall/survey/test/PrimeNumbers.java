package com.hendall.survey.test;

public class PrimeNumbers {



	public static void main(String[] args) {
String str="No observation available (if selected, questions 4.D.1 - 4.D.3 will be blocked)Test check box ";
String[] array=str.split("#*#");
System.out.println(array.length);
	}

}