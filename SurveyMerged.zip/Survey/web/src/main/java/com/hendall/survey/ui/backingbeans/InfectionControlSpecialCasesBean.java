package com.hendall.survey.ui.backingbeans;

import java.util.List;

import com.hendall.survey.services.common.ServiceConstants;
import com.hendall.survey.services.datamodel.Answer;
import com.hendall.survey.services.datamodel.Options;
import com.hendall.survey.services.datamodel.Question;
import com.hendall.survey.services.datamodel.Section;

public class InfectionControlSpecialCasesBean {

	public void processDropDowns(String id, String value, List<Section> masterSurveyQuestionSectionList) {
populateHospitalNames(id, value, masterSurveyQuestionSectionList);
	}

	private void populateHospitalNames(String id, String value, List<Section> masterSurveyQuestionSectionList) {
for (Section section : masterSurveyQuestionSectionList) {
	for (Question question : section.getSurveyQuestionAnswerList()) {
for (Answer answer : question.getAnswersList()) {
	if (id.equals("surveryQuestionForm:sectionLoop:0:questionAnswerLoop:0:answerLoop:0:selectOneMenu") && answer
	.getHtmlControlId() == ServiceConstants.INFECTION_CONTROL_HOSPITAL_NAME_CONTROL_ID) {
List<Options> optionsList = answer.getDependentHtmlOptionsMap().get(value);
answer.setHtmlOptions(optionsList);

	}
}
	}
}

	}
}
