package com.hendall.survey.services.ejb;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import org.apache.commons.lang3.StringUtils;

import com.hendall.survey.services.assemblers.ValidationAssembler;
import com.hendall.survey.services.common.ServiceConstants;
import com.hendall.survey.services.datamodel.Answer;
import com.hendall.survey.services.datamodel.Question;
import com.hendall.survey.services.datamodel.Section;
import com.hendall.survey.services.datamodel.Validation;

@Stateless
@LocalBean
public class ValidationService {

	private Map<Integer, Answer> answersMap = new HashMap<Integer, Answer>();

	private static String SURVEY_QUESTION_FORM = "surveryQuestionForm";
	private static String SECTION_LOOP = ":sectionLoop";
	private static String QUESTION_ANSWER_LOOP = ":questionAnswerLoop";
	private static String ANSWER_LOOP = ":answerLoop";
	private static String ERROR_MESSAGE = ":errorMessage";

	public List<Validation> getValidationsList(List<Section> surveyQuestionSectionList) {
populateAnswersMap(surveyQuestionSectionList);
List<Validation> validationsList = new ArrayList<Validation>();
int sectionCount = 0;

for (Section section : surveyQuestionSectionList) {
	int questionAnswerCount = 0;
	for (Question question : section.getSurveyQuestionAnswerList()) {
int answerCount = 0;
for (Answer answer : question.getAnswersList()) {

	Validation validation = new Validation();
	validation.setSectionIndex(sectionCount + 1);
	validation.setQuestion(question.getQuestionText());
	ValidationAssembler.populateValidationObject(answer, validation, answersMap);
	String errorId = SURVEY_QUESTION_FORM + SECTION_LOOP + ":" + sectionCount + QUESTION_ANSWER_LOOP
	+ ":" + questionAnswerCount + ANSWER_LOOP + ":" + answerCount + ERROR_MESSAGE;
	validation.setErrorMessageCompId(errorId);
	if (StringUtils.isNotEmpty(validation.getMessage())) {
validationsList.add(validation);
	}

	answerCount++;
}
questionAnswerCount++;
	}
	sectionCount++;
}
return validationsList;
	}

	private void populateAnswersMap(List<Section> surveyQuestionSectionList) {
for (Section section : surveyQuestionSectionList) {
	for (Question question : section.getSurveyQuestionAnswerList()) {
for (Answer answer : question.getAnswersList()) {
	answersMap.put(answer.getHtmlControlId(), answer);
}
	}

}
	}

}
