package com.hendall.survey.services.common;

import java.util.ArrayList;
import java.util.List;

public class ServiceConstants {
	private ServiceConstants() {
	}
	
	public static String PROPERTIES_FOLDER="survey.folderpath";
	public static String PROPERTIES_FILE="survey.jsonfile";
	
	public static String STATUS_REJECT="Rejected";
	public static String STATUS_APPROVE="Approved";
	public static String STATUS_IN_PROGRESS="In Progress";
	public static String STATUS_IN_PENDING_REVIEW="Pending Review";
	public static String STATUS_IN_SUBMITTED="Submitted";

	public static String EMAIL_FROM_ADDRESS="kalyan.pamula@hendall.com";
	
	public static String EMAIL_SUBJECT="New Survey Review pending";
	public static String EMAIL_MESSAGE="New survey has been assginged to you. Please login to your account.";
	
	
	public static Integer INFECTION_CONTROL_STATE_CONTROL_ID = 100;
	public static Integer INFECTION_CONTROL_HOSPITAL_NAME_CONTROL_ID = 200;
	public static final Integer INFECTION_CONTROL_ADDTIONAL_COMMENTS_ID=-1;
	public static final String INFECTION_CONTROL_ADDTIONAL_COMMENTS_QUESTION="You can use this section to include any additional comments or observations you may have, regarding this survey.";
	public static final String INFECTION_CONTROL_ADDTIONAL_COMMENTS_SECTION_TITLE="Survey Notes";
	
	
	public static final Integer INFECTION_CONTROL_APPROVER_ID=-2;
	public static final String INFECTION_CONTROL_ADDTIONAL_APPROVER_DETAILS_SECTION_TITLE="Survey Approver Details";
	public static final String INFECTION_CONTROL_ADDTIONAL_APPROVER_DETAILS_QUESTION="Please enter the email address of your supervisor in this section. \n Upon submission of the survey, an email will be sent to your supervisor, for their appproval.";
	public static final String INFECTION_CONTROL_ADDTIONAL_APPROVER_EMAIL="Supervisor Email Address:";
	
	
	public static final String DATA_SAPERATOR = "\\|\\|";

	public static final String HTML_CONTROL_RADIO = "radio";
	public static final String HTML_CONTROL_CHECK_BOX = "checkbox";
	public static final String HTML_CONTROL_SELECT = "select";
	public static final String HTML_CONTROL_TEXT_BOX = "textbox";
	public static final String HTML_CONTROL_DATE = "date";
	public static final String HTML_CONTROL_NUMBER = "number";
	public static final String HTML_CONTROL_TEXT_AREA = "textarea";
	public static final List<String> inputTextComponents = new ArrayList<String>();
	public static final List<String> singleValueCompoents = new ArrayList<String>();
	public static final List<String> multipleSelectionComponents = new ArrayList<String>();

	public static final String REQUEIRED_MESSAGE = "Required.";

	static {
inputTextComponents.add(HTML_CONTROL_TEXT_BOX);
inputTextComponents.add(HTML_CONTROL_DATE);
inputTextComponents.add(HTML_CONTROL_NUMBER);
inputTextComponents.add(HTML_CONTROL_TEXT_AREA);

singleValueCompoents.add(HTML_CONTROL_TEXT_BOX);
singleValueCompoents.add(HTML_CONTROL_DATE);
singleValueCompoents.add(HTML_CONTROL_NUMBER);
singleValueCompoents.add(HTML_CONTROL_TEXT_AREA);
singleValueCompoents.add(HTML_CONTROL_RADIO);
singleValueCompoents.add(HTML_CONTROL_SELECT);

multipleSelectionComponents.add(HTML_CONTROL_RADIO);
multipleSelectionComponents.add(HTML_CONTROL_CHECK_BOX);
multipleSelectionComponents.add(HTML_CONTROL_SELECT);
	}

}
