package com.hendall.survey.services.ejb;

import java.util.List;

import javax.ejb.Stateless;

import com.hendall.survey.services.assemblers.SurveyQuestionsFormAssembler;
import com.hendall.survey.services.common.ServiceConstants;
import com.hendall.survey.services.datamodel.SectionHelpWrapper;
import com.hendall.survey.services.schematopojo.ClassName;
import com.hendall.survey.util.JsonUtil;
import com.hendall.survey.util.ServiceUtils;

/**
 * Session Bean implementation class QuestionsService
 */
@Stateless

public class QuestionsService {

	/**
	 * Default constructor.
	 */
	public QuestionsService() {

	}
	
	public SectionHelpWrapper getQuestions(){
SectionHelpWrapper sectionHelpWrapperList = new SectionHelpWrapper();
ClassName className=JsonUtil.readFromFile(getFileUrl());
SurveyQuestionsFormAssembler.assebleViewObject(className, sectionHelpWrapperList);
return sectionHelpWrapperList;

	}
	
	
	
	
	private String getFileUrl(){
return ServiceUtils.getPropety(ServiceConstants.PROPERTIES_FOLDER)+"/"+ServiceUtils.getPropety(ServiceConstants.PROPERTIES_FILE);
	}
	
	public int getNumberOfSectionsPerPage(String client){
return 1;
	}

}
